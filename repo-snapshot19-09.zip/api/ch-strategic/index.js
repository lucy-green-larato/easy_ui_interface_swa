'use strict';

const { createHandler } = require('azure-function-express');
const express = require('express');
const multer = require('multer');

// shared module (go UP one level from /api/ch-strategic/)
const chStrategic = require('../generate/kinds/ch-strategic');

const app = express();

// Parse bodies with sensible limits
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '16kb' }));

// CORS for SWA front end + Functions API
app.use((req, res, next) => {
  res.set({
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'authorization, content-type, x-ms-client-principal'
  });
  next();
});

// Handle all preflight requests EARLY and STOP processing
app.options('*', (req, res) => {
  res.status(204).end();
});

// OPTIONAL: strict allow-lists for future /api/pbi-export usage
// Provide as JSON in env CH_STRATEGIC_PBI_ALLOW, e.g.:
// {"workspaces":["..."],"reports":["..."],"visuals":["..."]}
const allowPbi = (() => {
  try {
    return JSON.parse(process.env.CH_STRATEGIC_PBI_ALLOW || '{}');
  } catch {
    return {};
  }
})();

// ---- principal extractor (SWA) + role gate helper ----
function getPrincipal(req) {
  try {
    const b64 = req.headers['x-ms-client-principal'];
    if (!b64) return null;
    const json = Buffer.from(b64, 'base64').toString('utf8');
    return JSON.parse(json);
  } catch {
    return null;
  }
}

function requireRole(role) {
  return (req, res, next) => {
    const p = getPrincipal(req);
    const roles = (p && Array.isArray(p.userRoles)) ? p.userRoles : [];
    if (!roles.includes(role)) {
      return res.status(403).json({ error: `Forbidden: missing role ${role}` });
    }
    return next();
  };
}

// ---- polished in-memory rate limiter ----
const RPM = parseInt(process.env.CH_STRATEGIC_RPM || '60', 10);
const WINDOW_MS = 60_000;
const buckets = new Map();
setInterval(() => {
  // GC buckets every minute
  const now = Date.now();
  for (const [k, v] of buckets) if (now - v.ts > WINDOW_MS * 2) buckets.delete(k);
}, WINDOW_MS).unref();

function rateLimit(req, res, next) {
  const now = Date.now();
  const p = getPrincipal(req);
  const key = p?.userId ? `p:${p.userId}` : `ip:${req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown'}`;
  const b = buckets.get(key) || { ts: now, count: 0 };
  if (now - b.ts > WINDOW_MS) { b.ts = now; b.count = 0; }
  b.count += 1;
  buckets.set(key, b);
  if (b.count > RPM) return res.status(429).json({ error: 'Too many requests, please slow down.' });
  next();
}

// apply limiter to all ch-strategic routes
app.use(rateLimit);

// only authenticated users get through
const { v4: uuidv4 } = require('uuid');
const { error } = require('../lib/http');
const { getPrincipal } = require('../lib/auth'); // your SWA helper

// Attach correlationId + verify SWA principal
app.use('/ch-strategic', (req, res, next) => {
  const cid = uuidv4();
  req.correlationId = cid;

  const principal = getPrincipal(req);
  if (!principal) {
    return error(res, 401, 'Unauthenticated', undefined, cid);
  }
  req.principal = principal;

  // Useful for tracing
  res.setHeader('X-Correlation-Id', cid);

  next();
});

// --- Role-based PBI export endpoint ---
function requireRole(role) {
  return (req, res, next) => {
    const roles = req.principal?.userRoles || [];
    if (!roles.includes(role)) {
      return error(
        res,
        403,
        `Missing required role: ${role}`,
        undefined,
        req.correlationId
      );
    }
    next();
  };
}

app.post('/pbi-export',
  requireRole('pbi-exporter'),
  async (req, res) => {
    try {
      // TODO: your Power BI export logic
      res.json({ ok: true, cid: req.correlationId });
    } catch (err) {
      return error(res, err.status || 500, err.message || 'Internal error', undefined, req.correlationId);
    }
  }
);

const { error } = require('../lib/http'); // already present earlier
// principal/correlation middleware should already be here, e.g. app.use('/ch-strategic', ...)

// --- Feedback RPM limiter (run BEFORE mount) ---
const feedbackCounts = new Map();
const FEEDBACK_RPM = parseInt(process.env.CH_STRATEGIC_FEEDBACK_RPM || '5', 10);

function actorKey(req) {
  const p = req.principal;
  if (p?.userId) return `p:${p.userId}`;
  const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  return `ip:${ip || 'unknown'}`;
}

// reset counts every minute
setInterval(() => { feedbackCounts.clear(); }, 60 * 1000).unref();

function limitFeedback(req, res, next) {
  const k = actorKey(req);
  const n = (feedbackCounts.get(k) || 0) + 1;
  feedbackCounts.set(k, n);
  if (n > FEEDBACK_RPM) {
    return res.status(429).json({
      code: 429,
      message: 'Too many feedback submissions. Please wait a minute.',
      correlationId: req.correlationId
    });
  }
  next();
}

// Mount all ch-strategic endpoints from the shared module.
// IMPORTANT: pass the multer **module**, not a preconfigured instance.
chStrategic.mount(app, { multer, allowPbi });

// One-response-only safety net
app.use((err, req, res, next) => {
  if (res.headersSent) return;
  res.status(err.status || 500).json({ error: err.message || 'Internal error' });
});

app.get('/ch-strategic/_health', (req, res) => {
  res.status(200).json({ ok: true });
});

module.exports = createHandler(app);

